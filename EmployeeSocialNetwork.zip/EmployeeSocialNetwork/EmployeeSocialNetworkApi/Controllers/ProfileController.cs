﻿using System.Collections.Generic;
using Domain.Interfaces;
using Domain.Model;
using Infrastructure.Business;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace EmployeeSocialNetworkApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProfileController : ControllerBase
    {
        private readonly ILogger<ProfileController> _logger;

        public ProfileController(ILogger<ProfileController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Route("GetAll")]
        public IEnumerable<Employee> Get([FromServices] IEmployeeRepository employeeRepository)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            return userAccount.GetAllEmployees();
        }

        [HttpGet]
        [Route("GetByName/{name}")]
        public IEnumerable<Employee> GetByName([FromServices] IEmployeeRepository employeeRepository, string name)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            return userAccount.GetEmployeesByName(name);
        }

        [HttpGet]
        [Route("GetByDepartment/{department}")]
        public IEnumerable<Employee> GetByDepartment([FromServices] IEmployeeRepository employeeRepository, string department)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            return userAccount.GetEmployeesByDepartment(department);
        }

        [HttpGet]
        [Route("GetFavorites")]
        public IEnumerable<Employee> GetFavorites([FromServices] IEmployeeRepository employeeRepository)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            return userAccount.GetFavoritesEmployees();
        }

        [HttpPost]
        [Route("AddComment")]
        public void AddComment([FromServices] IEmployeeRepository employeeRepository, int employeeId, string commentText)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            userAccount.AddCommentToEmployee(employeeId, commentText);
        }

        [HttpPost]
        [Route("AddToFavorites")]
        public void AddToFavorites([FromServices] IEmployeeRepository employeeRepository, int employeeId)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            userAccount.AddProfileToFavorites(employeeId);
        }

        [HttpPost]
        [Route("LikeProfile")]
        public void LikeProfile([FromServices] IEmployeeRepository employeeRepository, int employeeId)
        {
            EmployeeAccount userAccount = new EmployeeAccount(employeeRepository, "Sasha1", "Sales");
            userAccount.LikeProfile(employeeId);
        }
    }
}
