﻿using System;

namespace Domain.Model
{
    public class Comment
    {
        public int Id { get; set; }
        public string Author { get; set; }
        public DateTime CreationDate { get; set; }
        public string Text { get; set; }

        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
