﻿namespace Domain.Model
{
    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool IsBlocked { get; set; } = false;

        public int? RoleId { get; set; }
        public Role Role { get; set; }

        public int? EmployeeProfileId { get; set; }
        public Employee EmployeeProfile { get; set; }
    }
}
