﻿using System.Collections.Generic;

namespace Domain.Model
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public int LikesNumber { get; set; }
        public List<Comment> Comments { get; set; }
    }
}
