﻿using Domain.Interfaces;
using Domain.Model;

namespace Infrastructure.Business
{
    public class AdminAccount : EmployeeAccount
    {
        private IUserRepository userRepos;

        public AdminAccount(IEmployeeRepository employeeRepository, IUserRepository userRepository, string name, string department) 
            : base(employeeRepository, name, department) 
        {
            userRepos = userRepository;
        }

        public void BlockProfile(int profileId)
        {
            User user = userRepos.GetUser(profileId);
            user.IsBlocked = true;
        }

        public void UnlockProfile(int profileId)
        {
            User user = userRepos.GetUser(profileId);
            user.IsBlocked = false;
        }
    }
}
