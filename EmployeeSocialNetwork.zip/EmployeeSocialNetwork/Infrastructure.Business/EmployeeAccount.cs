﻿using Domain.Interfaces;
using Domain.Model;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Business
{
    public class EmployeeAccount : IAccount
    {
        public string Name { get; set; }
        public string Department { get; set; }

        private IEmployeeRepository repos;
        private List<Employee> favoritesEmployees;

        public EmployeeAccount(IEmployeeRepository employeeRepository, string name, string department)
        {
            if (employeeRepository == null || String.IsNullOrEmpty(name) || String.IsNullOrEmpty(department))
                throw new ArgumentNullException("Не задан один из параметров для аккаунта!");

            repos = employeeRepository;
            Name = name;
            Department = department;

            favoritesEmployees = new List<Employee>();
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            return repos.GetEmployeeList();
        }

        public IEnumerable<Employee> GetEmployeesByName(string name)
        {
            if (String.IsNullOrEmpty(name))
                throw new ArgumentNullException();

            return repos.GetEmployeesByName(name);
        }

        public IEnumerable<Employee> GetEmployeesByDepartment(string department)
        {
            if (String.IsNullOrEmpty(department))
                throw new ArgumentNullException();

            return repos.GetEmployeesByDepartment(department);
        }

        public IEnumerable<Employee> GetFavoritesEmployees()
        {
            foreach(Employee employee in favoritesEmployees)
            {
                yield return employee;
            }
        }

        public void AddCommentToEmployee(int employeeId, string commentText)
        {
            if (String.IsNullOrEmpty(commentText))
                throw new ArgumentNullException();

            Employee employee = repos.GetEmployee(employeeId);
            Comment comment = new Comment { Author = Name, CreationDate = DateTime.Now, Text = commentText };

            employee.Comments.Add(comment);
        }

        public void AddProfileToFavorites(int employeeId)
        {
            Employee employee = repos.GetEmployee(employeeId);
            favoritesEmployees.Add(employee);
        }

        public void LikeProfile(int employeeId)
        {
            Employee employee = repos.GetEmployee(employeeId);
            employee.LikesNumber++;
        }

        public IEnumerable<Comment> GetSortedComments(int employeeId)
        {
            Employee employee = repos.GetEmployee(employeeId);
            return employee.Comments.OrderByDescending(c => c.CreationDate);
        }
    }
}
