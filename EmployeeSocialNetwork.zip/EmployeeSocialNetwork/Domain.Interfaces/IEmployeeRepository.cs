﻿using Domain.Model;
using System;
using System.Collections.Generic;

namespace Domain.Interfaces
{
    public interface IEmployeeRepository: IDisposable
    {
        IEnumerable<Employee> GetEmployeeList();
        IEnumerable<Employee> GetEmployeesByName(string name);
        IEnumerable<Employee> GetEmployeesByDepartment(string department);
        Employee GetEmployee(int id);
        void Create(Employee item);
        void Update(Employee item);
        void Delete(int id);
        void Save();
    }
}
