﻿using Domain.Model;
using System;
using System.Collections.Generic;

namespace Domain.Interfaces
{
    public interface ICommentRepository : IDisposable
    {
        IEnumerable<Comment> GetCommentList();
        Comment GetComment(int id);
        void Create(Comment item);
        void Update(Comment item);
        void Delete(int id);
        void Save();
    }
}
