﻿using Domain.Model;
using System.Collections.Generic;

namespace Services.Interfaces
{
    public interface IAccount
    {
        IEnumerable<Employee> GetAllEmployees();
        IEnumerable<Employee> GetEmployeesByName(string name);
        IEnumerable<Employee> GetEmployeesByDepartment(string department);
        IEnumerable<Employee> GetFavoritesEmployees();
        void AddCommentToEmployee(int employeeId, string comment);
        void AddProfileToFavorites(int employeeId);
        void LikeProfile(int employeeId);
        IEnumerable<Comment> GetSortedComments(int employeeId);
    }
}
