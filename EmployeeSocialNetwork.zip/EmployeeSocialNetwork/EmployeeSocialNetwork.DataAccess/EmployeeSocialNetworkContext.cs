﻿using System;
using Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace EmployeeSocialNetwork.DataAccess
{
    public class EmployeeSocialNetworkContext : DbContext
    {
        public DbSet<Employee> EmployeeProfiles { get; set; }
        public DbSet<Comment> Comments { get; set; }

        public EmployeeSocialNetworkContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=Александр-TOSH;Database=EmployeeSocialNetwork;Trusted_Connection=True;");
        }
    }
}
